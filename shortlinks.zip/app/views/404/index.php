<!DOCTYPE html>
<html>
<head>
    <?php
        $website_title='Страница не найдено';
        require 'public/blocks/head.php';
    ?>
</head>
<body>
    <?php require_once 'public/blocks/header.php'; ?>

    <div class="container">

     <a href="/"><img src="/public/img/404.png" alt="PAGE NOT FOUND"></a>
        
        
    </div>

  
</body>
</html>