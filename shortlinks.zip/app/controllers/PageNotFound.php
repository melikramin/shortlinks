<?php
    class PageNotFound extends Controller {
        public function index() {
            $this->view('404/index');
        }

       
    }